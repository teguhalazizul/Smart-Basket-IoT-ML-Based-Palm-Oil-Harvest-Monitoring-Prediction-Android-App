package com.example.kebun_link

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.kebun_link.api.TimbanganApiClient
import com.example.kebun_link.databinding.FragmentDashboardBinding
import com.example.kebun_link.model.DashboardStats
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.ValueFormatter
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch
import android.widget.LinearLayout
import android.content.res.ColorStateList
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.YAxis
import java.text.SimpleDateFormat
import java.util.*

class FragmentDashboard : Fragment() {
    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private var dashboardStats: DashboardStats = DashboardStats()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup toolbar
        (requireActivity() as AppCompatActivity).setSupportActionBar(binding.toolbar)
        (requireActivity() as AppCompatActivity).supportActionBar?.apply {
            title = "Analitik Panen"
        }

        // Setup refresh dengan warna orange
        binding.swipeRefresh.setProgressBackgroundColorSchemeColor(Color.parseColor("#FFF3E0"))
        binding.swipeRefresh.setColorSchemeColors(
            Color.parseColor("#FF9800"),
            Color.parseColor("#FB8C00"),
            Color.parseColor("#F57C00")
        )

        binding.swipeRefresh.setOnRefreshListener {
            loadDashboardData()
        }

        // Load data awal
        loadDashboardData()
    }

    private fun loadDashboardData() {
        showLoading(true)

        lifecycleScope.launch {
            try {
                // 1. Ambil data dari API
                val rawData = TimbanganApiClient.apiService.getDataAnalitik()

                if (rawData.isEmpty()) {
                    showEmptyState()
                    return@launch
                }

                // 2. Hitung statistik
                dashboardStats = TimbanganApiClient.calculateDashboardStats(rawData)

                // 3. Update UI
                updateUI()

                // 4. Setup charts
                setupCharts()

                // Sembunyikan empty state
                binding.layoutEmptyState.visibility = View.GONE

            } catch (e: Exception) {
                Log.e("FragmentDashboard", "Error: ${e.message}")
                showError("Gagal memuat data analitik: ${e.message}")
            } finally {
                showLoading(false)
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun updateUI() {
        // Update last update dengan format yang lebih baik
        updateLastUpdateTime()

        // 1. UPDATE KPI CARDS dengan warna yang lebih menarik
        updateKpiCard(
            binding.cardTotal.root,
            "📊 Total Panen",
            String.format("%.2f", dashboardStats.totalPanenKeseluruhan),
            "kg",
            "Keseluruhan produksi",
            Color.parseColor("#FF9800") // ORANGE UTAMA
        )

        updateKpiCard(
            binding.cardRataRata.root,
            "📈 Rata-rata",
            String.format("%.2f", dashboardStats.rataRataPerSesi),
            "kg/sesi",
            "Per sesi timbang",
            Color.parseColor("#2196F3") // BIRU SEGAR
        )

        updateKpiCard(
            binding.cardTertinggi.root,
            "🏆 Tertinggi",
            String.format("%.2f", dashboardStats.panenTertinggi),
            "kg",
            "Rekor produksi",
            Color.parseColor("#4CAF50") // HIJAU SEGAR
        )

        updateKpiCard(
            binding.cardSesi.root,
            "📋 Jumlah Sesi",
            dashboardStats.jumlahSesi.toString(),
            "sesi",
            "Total pencatatan",
            Color.parseColor("#9C27B0") // UNGU ELEGAN
        )
    }

    private fun updateLastUpdateTime() {
        val currentTime = SimpleDateFormat("HH:mm", Locale.getDefault())
            .format(Date())
        binding.tvLastUpdate.text = currentTime
    }

    private fun updateKpiCard(
        cardView: View,
        title: String,
        value: String,
        unit: String,
        subtitle: String,
        color: Int
    ) {
        // 1. Update teks
        cardView.findViewById<androidx.appcompat.widget.AppCompatTextView>(R.id.tvTitle).text = title
        cardView.findViewById<androidx.appcompat.widget.AppCompatTextView>(R.id.tvValue).text = value
        cardView.findViewById<androidx.appcompat.widget.AppCompatTextView>(R.id.tvUnit).text = unit
        cardView.findViewById<androidx.appcompat.widget.AppCompatTextView>(R.id.tvSubtitle).text = subtitle

        // 2. Update icon color
        val icon = cardView.findViewById<androidx.appcompat.widget.AppCompatImageView>(R.id.ivIcon)
        icon.setColorFilter(color)

        // 3. Set card background tint dengan alpha yang lebih halus
        cardView.findViewById<LinearLayout>(R.id.rootLayout).backgroundTintList =
            ColorStateList.valueOf(color.withAlpha(15))

        // 4. Tambahkan efek shadow pada card
        cardView.elevation = 6f
    }

    private fun setupCharts() {
        // 1. TREND PRODUKSI (LINE CHART)
        setupTrendChart()

        // 2. PERBANDINGAN TAHUNAN (BAR CHART)
        setupTahunanChart()
    }

    private fun setupTrendChart() {
        val chart = binding.chartTrend
        val entries = ArrayList<Entry>()

        dashboardStats.trendBulanan.forEachIndexed { index, pair ->
            entries.add(Entry(index.toFloat(), pair.second.toFloat()))
        }

        if (entries.isEmpty()) {
            binding.chartTrend.visibility = View.GONE
            return
        }

        val dataSet = LineDataSet(entries, "Produksi Bulanan")
        dataSet.color = Color.parseColor("#FF9800")
        dataSet.lineWidth = 3f
        dataSet.setDrawCircles(true)
        dataSet.setCircleColor(Color.parseColor("#FF9800"))
        dataSet.circleRadius = 5f
        dataSet.circleHoleRadius = 3f
        dataSet.circleHoleColor = Color.WHITE
        dataSet.valueTextColor = Color.parseColor("#5D4037")
        dataSet.valueTextSize = 10f
        dataSet.mode = LineDataSet.Mode.CUBIC_BEZIER
        dataSet.cubicIntensity = 0.2f
        dataSet.fillAlpha = 20
        dataSet.fillColor = Color.parseColor("#FF9800")
        dataSet.setDrawFilled(true)
        dataSet.setDrawCircleHole(true)
        dataSet.setDrawValues(false) // Sembunyikan nilai di titik

        // Gradient untuk fill - FIXED VERSION
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
            val gradient = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#40FF9800"), Color.TRANSPARENT)
            )
            dataSet.fillDrawable = gradient
        }

        val lineData = LineData(dataSet)
        lineData.setValueTextColor(Color.parseColor("#5D4037"))
        lineData.setValueTextSize(10f)

        chart.data = lineData

        // Konfigurasi chart yang lebih elegan
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.setDrawGridBackground(false)
        chart.setDrawBorders(false)
        chart.setTouchEnabled(true)
        chart.setPinchZoom(true)
        chart.setScaleEnabled(true)
        chart.setDrawBorders(false)
        chart.setBorderWidth(0f)
        chart.setBackgroundColor(Color.TRANSPARENT)
        chart.animateX(1200)

        // Setup X axis
        val xAxis = chart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.setDrawGridLines(false)
        xAxis.granularity = 1f
        xAxis.labelCount = minOf(6, dashboardStats.trendBulanan.size)
        xAxis.textColor = Color.parseColor("#8D6E63")
        xAxis.textSize = 11f
        xAxis.axisLineColor = Color.parseColor("#FFE0B2")
        xAxis.axisLineWidth = 1f
        xAxis.setAvoidFirstLastClipping(true)

        // Format bulan
        xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                val index = value.toInt()
                return if (index in dashboardStats.trendBulanan.indices) {
                    dashboardStats.trendBulanan[index].first
                } else {
                    ""
                }
            }
        }

        // Setup Y axis kiri
        val yAxis = chart.axisLeft
        yAxis.setDrawGridLines(true)
        yAxis.gridColor = Color.parseColor("#40FFE0B2")
        yAxis.gridLineWidth = 1f
        yAxis.axisMinimum = 0f
        yAxis.textColor = Color.parseColor("#8D6E63")
        yAxis.textSize = 11f
        yAxis.axisLineColor = Color.parseColor("#FFE0B2")
        yAxis.axisLineWidth = 1f
        yAxis.setDrawZeroLine(true)
        yAxis.zeroLineColor = Color.parseColor("#FFE0B2")
        yAxis.zeroLineWidth = 1f
        yAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                return if (value >= 1000) {
                    String.format("%.1fK", value / 1000)
                } else {
                    String.format("%.0f", value)
                }
            }
        }

        // Nonaktifkan axis kanan
        chart.axisRight.isEnabled = false

        // Setup legend
        val legend = chart.legend
        legend.isEnabled = true
        legend.textColor = Color.parseColor("#8D6E63")
        legend.textSize = 11f
        legend.formSize = 12f
        legend.form = Legend.LegendForm.LINE
        legend.horizontalAlignment = Legend.LegendHorizontalAlignment.CENTER
        legend.verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
        legend.orientation = Legend.LegendOrientation.HORIZONTAL
        legend.setDrawInside(false)
        legend.xEntrySpace = 20f
        legend.yEntrySpace = 0f
        legend.yOffset = 10f

        chart.invalidate()
    }

    private fun setupTahunanChart() {
        val chart = binding.chartTahunan
        val entries = ArrayList<BarEntry>()
        val labels = ArrayList<String>()

        dashboardStats.perbandinganTahunan.toList()
            .sortedBy { it.first }
            .forEachIndexed { index, pair ->
                entries.add(BarEntry(index.toFloat(), pair.second.toFloat()))
                labels.add(pair.first)
            }

        if (entries.isEmpty()) {
            binding.chartTahunan.visibility = View.GONE
            return
        }

        val dataSet = BarDataSet(entries, "Produksi Tahunan")
        dataSet.color = Color.parseColor("#2196F3")
        dataSet.valueTextColor = Color.parseColor("#5D4037")
        dataSet.valueTextSize = 10f
        dataSet.setDrawValues(true)
        dataSet.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                return if (value >= 1000) {
                    String.format("%.1fK", value / 1000)
                } else {
                    String.format("%.0f", value)
                }
            }
        }

        val barData = BarData(dataSet)
        barData.barWidth = 0.5f
        barData.setValueTextColor(Color.parseColor("#5D4037"))
        barData.setValueTextSize(10f)

        chart.data = barData

        // Konfigurasi chart
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.setDrawGridBackground(false)
        chart.setDrawBorders(false)
        chart.setTouchEnabled(true)
        chart.setPinchZoom(false)
        chart.setScaleEnabled(true)
        chart.setBackgroundColor(Color.TRANSPARENT)
        chart.animateY(1000)

        // Setup X axis
        val xAxis = chart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.setDrawGridLines(false)
        xAxis.granularity = 1f
        xAxis.textColor = Color.parseColor("#8D6E63")
        xAxis.textSize = 11f
        xAxis.axisLineColor = Color.parseColor("#FFE0B2")
        xAxis.axisLineWidth = 1f
        xAxis.setCenterAxisLabels(false)
        xAxis.setAvoidFirstLastClipping(true)
        xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                val index = value.toInt()
                return if (index in labels.indices) labels[index] else ""
            }
        }

        // Setup Y axis kiri
        val yAxis = chart.axisLeft
        yAxis.setDrawGridLines(true)
        yAxis.gridColor = Color.parseColor("#40FFE0B2")
        yAxis.gridLineWidth = 1f
        yAxis.axisMinimum = 0f
        yAxis.textColor = Color.parseColor("#8D6E63")
        yAxis.textSize = 11f
        yAxis.axisLineColor = Color.parseColor("#FFE0B2")
        yAxis.axisLineWidth = 1f
        yAxis.setDrawZeroLine(true)
        yAxis.zeroLineColor = Color.parseColor("#FFE0B2")
        yAxis.zeroLineWidth = 1f
        yAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                return if (value >= 1000) {
                    String.format("%.1fK", value / 1000)
                } else {
                    String.format("%.0f", value)
                }
            }
        }

        // Nonaktifkan axis kanan
        chart.axisRight.isEnabled = false

        chart.invalidate()
    }

    private fun showLoading(show: Boolean) {
        if (show) {
            binding.loadingOverlay.visibility = View.VISIBLE
            binding.layoutEmptyState.visibility = View.GONE
            binding.tvError.visibility = View.GONE
        } else {
            binding.loadingOverlay.visibility = View.GONE
        }
    }

    private fun showEmptyState() {
        binding.layoutEmptyState.visibility = View.VISIBLE
        binding.tvError.visibility = View.GONE
        binding.loadingOverlay.visibility = View.GONE
    }

    private fun showError(message: String) {
        binding.tvError.text = "❌ $message\n\n⚠️ Pastikan koneksi internet stabil\n🔄 Tarik ke bawah untuk mencoba lagi"
        binding.tvError.visibility = View.VISIBLE
        binding.layoutEmptyState.visibility = View.GONE
        binding.loadingOverlay.visibility = View.GONE

        Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG)
            .setBackgroundTint(Color.parseColor("#D32F2F"))
            .setTextColor(Color.WHITE)
            .setActionTextColor(Color.parseColor("#FFECB3"))
            .setAction("🔄 Coba Lagi") { loadDashboardData() }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

// Extension untuk color dengan alpha
fun Int.withAlpha(alpha: Int): Int {
    return Color.argb(
        alpha,
        Color.red(this),
        Color.green(this),
        Color.blue(this)
    )
}