package com.example.kebun_link.api

import com.example.kebun_link.model.TimbanganModel
import retrofit2.http.GET
import retrofit2.http.Query

interface TimbanganApiService {
    // 1. UNTUK FRAGMENT RIWAYAT (SEMUA DATA) - SUDAH ADA
    @GET("rest/v1/timbangan")
    suspend fun getTimbanganData(): List<TimbanganModel>

    // 2. UNTUK FRAGMENT HOME (HARI INI SAJA) - BARU
    @GET("rest/v1/timbangan")
    suspend fun getDataHariIni(
        @Query("order") order: String = "waktu.desc",
        @Query("select") select: String = "id,total_panen,waktu"
    ): List<TimbanganModel>
    // 3. Untuk Fragment Dashboard (analitik lengkap)
    @GET("rest/v1/timbangan")
    suspend fun getDataAnalitik(
        @Query("select") select: String = "total_panen,waktu",
        @Query("order") order: String = "waktu.asc"
    ): List<TimbanganModel>
}