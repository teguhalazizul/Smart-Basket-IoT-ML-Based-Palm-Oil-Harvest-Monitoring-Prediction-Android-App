package com.example.kebun_link.model

data class DashboardStats(
    // KPI Cards
    val totalPanenKeseluruhan: Double = 0.0,
    val rataRataPerSesi: Double = 0.0,
    val panenTertinggi: Double = 0.0,
    val jumlahSesi: Int = 0,

    // Data untuk grafik
    val trendBulanan: List<Pair<String, Double>> = emptyList(), // ("Jan", 1500.0)
    val perbandinganTahunan: Map<String, Double> = emptyMap(), // ("2023" to 12000.0)

    // PERHATIAN: analisisJam sudah dihapus

    // Waktu update
    val lastUpdate: String = ""
)