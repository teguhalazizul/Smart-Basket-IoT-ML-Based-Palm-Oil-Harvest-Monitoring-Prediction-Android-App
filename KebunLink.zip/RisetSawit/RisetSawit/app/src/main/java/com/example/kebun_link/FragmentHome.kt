package com.example.kebun_link

import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kebun_link.api.TimbanganApiClient
import com.example.kebun_link.databinding.FragmentHomeBinding
import com.example.kebun_link.databinding.ItemTodayCardBinding
import com.example.kebun_link.databinding.ItemTodayListBinding
import com.example.kebun_link.model.TimbanganModel
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class FragmentHome : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    // Binding untuk card khusus
    private lateinit var cardBinding: ItemTodayCardBinding

    // Data
    private var dataHariIni: List<TimbanganModel> = emptyList()
    private var totalKgHariIni = 0.0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        // Inflate binding untuk card
        cardBinding = ItemTodayCardBinding.bind(binding.root.findViewById(R.id.cardTodayStatus))

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup UI
        setupToolbar()
        setupRefresh()
        setupLogout()

        // Load data awal
        loadDataHariIni()
    }

    private fun setupToolbar() {
        (requireActivity() as AppCompatActivity).setSupportActionBar(binding.toolbar)
        (requireActivity() as AppCompatActivity).supportActionBar?.apply {
            title = "Dashboard Panen"
        }
    }

    private fun setupRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            loadDataHariIni()
        }

        // Gunakan cardBinding untuk akses tombol di card
        cardBinding.btnRefreshManual.setOnClickListener {
            loadDataHariIni()
            Snackbar.make(binding.root, "Memuat data terbaru...", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun loadDataHariIni() {
        binding.swipeRefresh.isRefreshing = true

        lifecycleScope.launch {
            try {
                // 1. AMBIL DATA DARI API
                val allData = TimbanganApiClient.apiService.getDataHariIni()

                // 2. FILTER HANYA DATA HARI INI
                val today = TimbanganApiClient.getTodayDate()
                dataHariIni = allData.filter { it.waktu.startsWith(today) }

                // 3. HITUNG TOTAL
                totalKgHariIni = dataHariIni.sumOf { it.totalPanen }

                // 4. UPDATE UI
                updateUI()

            } catch (e: Exception) {
                Log.e("FragmentHome", "Error: ${e.message}")
                showError("Gagal memuat data: ${e.message}")
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    // Tambahkan di dalam class FragmentHome
    private fun updateUI() {
        // Update tanggal di card
        val todayFormatted = TimbanganApiClient.formatTanggalIndonesia(Date())
        cardBinding.tvTanggal.text = todayFormatted

        // Update waktu update
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val currentTime = timeFormat.format(Date())
        binding.tvUpdateTime.text = "Terakhir update: $currentTime"

        // PERBAIKAN: Tampilkan data desimal dengan 2 angka di belakang koma
        binding.tvTotalKg.text = String.format("%.2f", totalKgHariIni)
        binding.tvJumlahData.text = dataHariIni.size.toString()

        if (dataHariIni.isEmpty()) {
            // TIDAK ADA DATA
            showNoDataState()
        } else {
            // ADA DATA
            showDataState()
        }
    }
    private fun showNoDataState() {
        // Card status
        cardBinding.layoutNoData.visibility = View.VISIBLE
        cardBinding.layoutWithData.visibility = View.GONE
        cardBinding.tvStatus.text = "TIDAK AKTIF"
        cardBinding.tvStatus.setBackgroundResource(R.drawable.bg_status_badge)

        // PERBAIKAN: format desimal
        cardBinding.tvTotalHariIni.text = "0.00 kg"
        cardBinding.tvLastUpdate.text = "--:--"

        // Statistik dashboard
        binding.tvTotalKg.text = "0.00"
        binding.tvJumlahData.text = "0"

        // List data
        binding.tvEmptyMessage.visibility = View.VISIBLE
        binding.rvDataToday.visibility = View.GONE
    }

    private fun showDataState() {
        // Card status
        cardBinding.layoutNoData.visibility = View.GONE
        cardBinding.layoutWithData.visibility = View.VISIBLE
        cardBinding.tvStatus.text = "AKTIF"
        cardBinding.tvStatus.setBackgroundResource(R.drawable.bg_status_badge)

        // PERBAIKAN: Update info di card dengan format desimal
        cardBinding.tvTotalHariIni.text = String.format("%.2f kg", totalKgHariIni)

        // Update waktu terakhir
        val lastTime = dataHariIni.lastOrNull()?.waktu ?: ""
        if (lastTime.isNotEmpty()) {
            val jamMenit = lastTime.substring(11, 16)
            cardBinding.tvLastUpdate.text = jamMenit
        }

        // PERBAIKAN: Update statistik dashboard dengan format desimal
        binding.tvTotalKg.text = String.format("%.2f", totalKgHariIni)
        binding.tvJumlahData.text = dataHariIni.size.toString()

        // Setup list
        setupRecyclerView()

        binding.tvEmptyMessage.visibility = View.GONE
        binding.rvDataToday.visibility = View.VISIBLE
    }

    private fun setupRecyclerView() {
        val adapter = TodayDataAdapter(dataHariIni)
        binding.rvDataToday.layoutManager = LinearLayoutManager(requireContext())
        binding.rvDataToday.adapter = adapter
    }

    private fun showError(message: String) {
        Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG)
            .setAction("Coba Lagi") { loadDataHariIni() }
            .show()
    }

    private fun setupLogout() {
        binding.btnLogoutUtama.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Konfirmasi Logout")
                .setMessage("Apakah Anda yakin ingin logout?")
                .setPositiveButton("Ya") { dialog, _ ->
                    val sharedPref = requireContext().getSharedPreferences("user_pref", MODE_PRIVATE)
                    val editor = sharedPref.edit()
                    editor.clear()
                    editor.apply()

                    dialog.dismiss()

                    val intent = Intent(requireContext(), Login::class.java)
                    startActivity(intent)
                    requireActivity().finish()
                }
                .setNegativeButton("Tidak") { dialog, _ ->
                    dialog.dismiss()
                    Snackbar.make(binding.root, "Logout dibatalkan", Snackbar.LENGTH_SHORT).show()
                }
                .show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

// Adapter untuk list data hari ini
class TodayDataAdapter(private val items: List<TimbanganModel>) :
    RecyclerView.Adapter<TodayDataAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemTodayListBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemTodayListBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        // Format waktu: "17:01"
        val jam = item.waktu.substring(11, 16)
        holder.binding.tvTime.text = jam

        // Format tanggal: "20 Des 2024"
        val tanggal = item.waktu.substring(0, 10)
        val parts = tanggal.split("-")
        val bulan = when (parts[1]) {
            "01" -> "Jan"; "02" -> "Feb"; "03" -> "Mar"; "04" -> "Apr"
            "05" -> "Mei"; "06" -> "Jun"; "07" -> "Jul"; "08" -> "Agu"
            "09" -> "Sep"; "10" -> "Okt"; "11" -> "Nov"; else -> "Des"
        }
        holder.binding.tvDate.text = "${parts[2]} $bulan ${parts[0]}"

        // PERBAIKAN: Tampilkan data desimal dengan 2 angka di belakang koma
        holder.binding.tvWeight.text = String.format("%.2f kg", item.totalPanen)
    }

    override fun getItemCount() = items.size
}