package com.example.kebun_link.model

import com.google.gson.annotations.SerializedName

data class TimbanganModel(
    @SerializedName("id")
    val id: Long,

    @SerializedName("total_panen")
    val totalPanen: Double,

    @SerializedName("waktu")
    val waktu: String // Format: "2023-01-09 17:01:16+00"
)