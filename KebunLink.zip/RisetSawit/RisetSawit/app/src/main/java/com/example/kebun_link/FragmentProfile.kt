package com.example.kebun_link

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.kebun_link.databinding.FragmentProfileBinding

class FragmentProfile : Fragment() {

    private val profileData = mapOf(
        "nama" to "Bapak Suroso",
        "id" to "P0012345",
        "lokasi" to "Desa Mekar Sari, Riau",
        "luas" to "5.5 Hektar",
        "kemitraan" to "Plasma - Kebun Link",
        "umur" to "7 Tahun",
        "profileImageUrl" to "https://placehold.co/150x150/FF9800/ffffff?text=BS"
    )

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Set Toolbar
        (requireActivity() as AppCompatActivity).setSupportActionBar(binding.toolbar)
        (requireActivity() as AppCompatActivity).supportActionBar?.apply {
            title = "Profil Petani"
        }

        // Isi data profil
        binding.tvNamaPetani.text = profileData["nama"]
        binding.tvIdPetani.text = "ID: ${profileData["id"]}"
        binding.tvLokasiLahan.text = profileData["lokasi"]
        binding.tvLuasLahan.text = profileData["luas"]
        binding.tvStatusKemitraan.text = profileData["kemitraan"]
        binding.tvUmurTanaman.text = profileData["umur"]

        // Load gambar dengan Glide
        val imageUrl = profileData["profileImageUrl"]
        if (imageUrl != null) {
            Glide.with(this)
                .load(imageUrl)
                .circleCrop()
                .placeholder(R.drawable.ic_profile_placeholder)
                .error(R.drawable.ic_profile_error)
                .into(binding.imgProfile)
        }

        // Set gradient background untuk card utama
        binding.cardProfile.background = resources.getDrawable(R.drawable.gradient_orange_card, null)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}