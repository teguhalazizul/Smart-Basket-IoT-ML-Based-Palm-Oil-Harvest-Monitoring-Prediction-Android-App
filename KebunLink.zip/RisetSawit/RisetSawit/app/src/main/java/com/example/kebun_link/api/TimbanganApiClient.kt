package com.example.kebun_link.api

import com.example.kebun_link.model.DashboardStats
import com.example.kebun_link.model.TimbanganModel
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

object TimbanganApiClient {
    private const val BASE_URL = "https://gdckkhvzxcxtwhmxuwef.supabase.co/"
    private const val API_KEY = "sb_publishable_XHoDZ9Ply3Z-xq4v8WgGPw_e_qbZZBJ"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            val request = chain.request().newBuilder()
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", "Bearer $API_KEY")
                .addHeader("Content-Type", "application/json")
                .build()
            chain.proceed(request)
        }
        .build()

    val apiService: TimbanganApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TimbanganApiService::class.java)
    }

    // Helper untuk mendapatkan tanggal hari ini
    fun getTodayDate(): String {
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return formatter.format(Date())
    }

    // Helper untuk format tanggal Indonesia
    fun formatTanggalIndonesia(date: Date): String {
        val formatter = SimpleDateFormat("dd MMMM yyyy", Locale("id", "ID"))
        return formatter.format(date)
    }

    // ===== FUNGSI ANALITIK DASHBOARD =====

    // Di dalam calculateDashboardStats():
    fun calculateDashboardStats(data: List<TimbanganModel>): DashboardStats {
        if (data.isEmpty()) return DashboardStats()

        // 1. KPI CALCULATIONS
        val totalPanen = data.sumOf { it.totalPanen }
        val rataRata = if (data.isNotEmpty()) totalPanen / data.size else 0.0
        val panenTertinggi = data.maxOfOrNull { it.totalPanen } ?: 0.0

        // 2. TREND BULANAN (12 bulan terakhir)
        val trendBulanan = calculateTrendBulanan(data)

        // 3. PERBANDINGAN TAHUNAN
        val perbandinganTahunan = calculatePerbandinganTahunan(data)

        // PERHATIAN: calculateAnalisisJam() sudah dihapus

        return DashboardStats(
            totalPanenKeseluruhan = totalPanen,
            rataRataPerSesi = rataRata,
            panenTertinggi = panenTertinggi,
            jumlahSesi = data.size,
            trendBulanan = trendBulanan,
            perbandinganTahunan = perbandinganTahunan,
            lastUpdate = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID"))
                .format(Date())
        )
    }

    // Hapus fungsi calculateAnalisisJam() dan semua fungsi terkait
    private fun calculateTrendBulanan(data: List<TimbanganModel>): List<Pair<String, Double>> {
        // Kelompokkan per bulan
        val monthlyMap = mutableMapOf<String, Double>()

        data.forEach { item ->
            try {
                val date = parseDate(item.waktu)
                val monthYear = SimpleDateFormat("MMM yyyy", Locale("id", "ID")).format(date)
                monthlyMap[monthYear] = monthlyMap.getOrDefault(monthYear, 0.0) + item.totalPanen
            } catch (e: Exception) {
                // Skip invalid dates
            }
        }

        // Ambil 12 bulan terakhir
        return monthlyMap.toList()
            .sortedByDescending { parseMonthYear(it.first) }
            .take(12)
            .reversed()
    }

    private fun calculatePerbandinganTahunan(data: List<TimbanganModel>): Map<String, Double> {
        val yearlyMap = mutableMapOf<String, Double>()

        data.forEach { item ->
            try {
                val date = parseDate(item.waktu)
                val year = SimpleDateFormat("yyyy", Locale.getDefault()).format(date)
                yearlyMap[year] = yearlyMap.getOrDefault(year, 0.0) + item.totalPanen
            } catch (e: Exception) {
                // Skip
            }
        }

        return yearlyMap
    }

    private fun calculateAnalisisJam(data: List<TimbanganModel>): Map<String, Int> {
        val hourMap = mutableMapOf<String, Int>()

        data.forEach { item ->
            try {
                // Ambil jam dari waktu
                if (item.waktu.length >= 16) {
                    val hour = item.waktu.substring(11, 13)
                    val hourLabel = "$hour:00"
                    hourMap[hourLabel] = hourMap.getOrDefault(hourLabel, 0) + 1
                }
            } catch (e: Exception) {
                // Skip
            }
        }

        return hourMap.toList()
            .sortedBy { it.first }
            .toMap()
    }

    private fun parseDate(utcTime: String): Date {
        return try {
            val cleanTime = utcTime.replace(" ", "T")
            val format = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
            format.parse(cleanTime) ?: Date()
        } catch (e: Exception) {
            Date()
        }
    }

    private fun parseMonthYear(monthYear: String): Date {
        val format = SimpleDateFormat("MMM yyyy", Locale("id", "ID"))
        return format.parse(monthYear) ?: Date()
    }
}