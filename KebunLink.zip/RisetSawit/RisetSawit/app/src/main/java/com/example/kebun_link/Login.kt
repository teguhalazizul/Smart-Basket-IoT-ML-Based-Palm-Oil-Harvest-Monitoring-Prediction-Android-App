package com.example.kebun_link

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.kebun_link.databinding.ActivityLoginBinding
import com.google.android.material.snackbar.Snackbar

class Login : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set status bar dan navigation bar color
        window.statusBarColor = resources.getColor(R.color.orange_dark, theme)
        window.navigationBarColor = resources.getColor(R.color.orange_dark, theme)

        val sharedPref = getSharedPreferences("user_pref", MODE_PRIVATE)

        binding.btnLogin.setOnClickListener {
            val username = binding.inputEmail.text.toString().trim()
            val password = binding.inputPass.text.toString().trim()
            val rememberMe = binding.checkRemember.isChecked

            // Validasi input
            if (username.isEmpty() || password.isEmpty()) {
                showError("Email dan password harus diisi")
                return@setOnClickListener
            }

            if (username == password) {
                val editor = sharedPref.edit()
                editor.putString("username", username)
                editor.putBoolean("isLogin", rememberMe)
                editor.apply()

                // Animasi button loading
                binding.btnLogin.text = "Logging in..."
                binding.btnLogin.isEnabled = false

                // Simulasi loading
                binding.root.postDelayed({
                    startActivity(Intent(this, BaseActivity::class.java))
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }, 500)

            } else {
                showErrorDialog("Login Gagal", "Username harus sama dengan Password untuk demo aplikasi.")
            }
        }

        binding.txtForgotPass.setOnClickListener {
            startActivity(Intent(this, ForgotPassword::class.java))
            overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right)
        }

        binding.txtSignUp.setOnClickListener {
            showSnackbar("Fitur Sign Up akan segera tersedia!")
        }

        // Auto-fill jika remember me aktif
        val savedUsername = sharedPref.getString("username", "")
        val isRemembered = sharedPref.getBoolean("isLogin", false)

        if (isRemembered && !savedUsername.isNullOrEmpty()) {
            binding.inputEmail.setText(savedUsername)
            binding.inputPass.setText(savedUsername)
            binding.checkRemember.isChecked = true
        }
    }

    private fun showError(message: String) {
        Snackbar.make(binding.root, message, Snackbar.LENGTH_SHORT)
            .setBackgroundTint(resources.getColor(R.color.orange_accent))
            .setTextColor(resources.getColor(R.color.white))
            .show()
    }

    private fun showErrorDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .create()
            .show()
    }

    private fun showSnackbar(message: String) {
        Snackbar.make(binding.root, message, Snackbar.LENGTH_SHORT)
            .setBackgroundTint(resources.getColor(R.color.orange_primary))
            .setTextColor(resources.getColor(R.color.white))
            .show()
    }
}