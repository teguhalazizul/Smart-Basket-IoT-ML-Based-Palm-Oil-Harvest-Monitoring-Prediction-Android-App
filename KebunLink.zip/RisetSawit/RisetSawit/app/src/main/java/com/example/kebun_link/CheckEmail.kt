package com.example.kebun_link

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.kebun_link.databinding.ActivityCheckEmailBinding

class CheckEmail : AppCompatActivity() {

    private lateinit var binding: ActivityCheckEmailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCheckEmailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val email = intent.getStringExtra("email_user")

        binding.txtInfo.text = """
            Kami telah mengirimkan link reset password ke alamat email:
            
            $email
            
            Silakan cek inbox atau folder spam Anda.
        """.trimIndent()

        binding.btnBackLogin.setOnClickListener {
            startActivity(Intent(this, Login::class.java))
            finish()
        }
    }
}
