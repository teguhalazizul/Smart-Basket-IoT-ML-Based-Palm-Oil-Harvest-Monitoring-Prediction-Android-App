package com.example.kebun_link

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.kebun_link.api.TimbanganApiClient
import com.example.kebun_link.databinding.FragmentRiwayatBinding
import kotlinx.coroutines.launch
import java.util.*

class FragmentRiwayat : Fragment() {

    private var _binding: FragmentRiwayatBinding? = null
    private val binding get() = _binding!!

    // Data
    private var originalData: List<Map<String, String>> = emptyList()
    private val filteredData = mutableListOf<Map<String, String>>()
    private lateinit var adapter: SimpleAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRiwayatBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Toolbar
        (requireActivity() as AppCompatActivity).setSupportActionBar(binding.toolbar)
        (requireActivity() as AppCompatActivity).supportActionBar?.title =
            "Riwayat Panen Sawit"

        setupListView()
        setupSearch()
        setupFilterTahun()

        binding.swipeRefreshLayout.setOnRefreshListener {
            loadTimbanganData()
        }

        loadTimbanganData()
    }

    // ================== LOAD DATA ==================
    private fun loadTimbanganData() {
        binding.progressBar.visibility = View.VISIBLE
        binding.tvError.visibility = View.GONE
        binding.layoutEmptyState.visibility = View.GONE

        lifecycleScope.launch {
            try {
                val response = TimbanganApiClient.apiService.getTimbanganData()

                // 🔹 Sort: TERBARU → TERLAMA
                val sorted = response.sortedByDescending { it.waktu }

                originalData = sorted.map { item ->
                    val tanggal = item.waktu.substring(0, 10)
                    val jam = item.waktu.substring(11, 16)
                    val tahun = tanggal.substring(0, 4)

                    mapOf(
                        "berat" to String.format("%.2f kg", item.totalPanen),
                        "detail" to "${formatTanggalIndo(tanggal)} • $jam",
                        "tahun" to tahun,
                        "raw" to item.waktu
                    )
                }

                binding.tvTotalRecords.text = "${originalData.size} data"
                applyFilter()

            } catch (e: Exception) {
                showError("Gagal memuat data: ${e.message}")
            } finally {
                binding.progressBar.visibility = View.GONE
                binding.swipeRefreshLayout.isRefreshing = false
            }
        }
    }

    // ================== LISTVIEW ==================
    private fun setupListView() {
        adapter = SimpleAdapter(
            requireContext(),
            filteredData,
            R.layout.item_riwayat_list,
            arrayOf("berat", "detail"),
            intArrayOf(R.id.tvBerat, R.id.tvDetail)
        )
        binding.listViewRiwayat.adapter = adapter

        binding.listViewRiwayat.setOnItemClickListener { _, _, position, _ ->
            val item = filteredData[position]
            Toast.makeText(
                requireContext(),
                "📊 ${item["berat"]}\n${item["detail"]}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    // ================== SEARCH ==================
    private fun setupSearch() {
        binding.etSearch.addTextChangedListener {
            applyFilter()
        }
    }

    // ================== FILTER TAHUN ==================
    private fun setupFilterTahun() {
        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        val tahunList = mutableListOf("Semua")

        for (i in currentYear downTo 2020) {
            tahunList.add(i.toString())
        }

        val spinnerAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            tahunList
        )

        binding.spinnerTahun.adapter = spinnerAdapter
        binding.spinnerTahun.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    applyFilter()
                }

                override fun onNothingSelected(parent: AdapterView<*>) {}
            }
    }

    // ================== APPLY FILTER ==================
    private fun applyFilter() {
        val keyword = binding.etSearch.text.toString().lowercase(Locale.getDefault())
        val selectedTahun = binding.spinnerTahun.selectedItem.toString()

        filteredData.clear()
        filteredData.addAll(
            originalData.filter {
                val cocokSearch =
                    it["berat"]!!.lowercase().contains(keyword) ||
                            it["detail"]!!.lowercase().contains(keyword)

                val cocokTahun =
                    selectedTahun == "Semua" || it["tahun"] == selectedTahun

                cocokSearch && cocokTahun
            }
        )

        adapter.notifyDataSetChanged()

        if (filteredData.isEmpty()) {
            binding.layoutEmptyState.visibility = View.VISIBLE
            binding.listViewRiwayat.visibility = View.GONE
        } else {
            binding.layoutEmptyState.visibility = View.GONE
            binding.listViewRiwayat.visibility = View.VISIBLE
        }

        binding.tvTotalRecords.text = "${filteredData.size} data"
    }

    // ================== UTIL ==================
    private fun formatTanggalIndo(tanggal: String): String {
        val p = tanggal.split("-")
        val bulan = arrayOf(
            "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
            "Jul", "Agu", "Sep", "Okt", "Nov", "Des"
        )
        return "${p[2]} ${bulan[p[1].toInt() - 1]} ${p[0]}"
    }

    private fun showError(message: String) {
        binding.tvError.text = message
        binding.tvError.visibility = View.VISIBLE
        binding.listViewRiwayat.visibility = View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
