package com.example.kebun_link

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.kebun_link.databinding.ActivityForgotPasswordBinding

class ForgotPassword : AppCompatActivity() {

    private lateinit var binding: ActivityForgotPasswordBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityForgotPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnResetPassword.setOnClickListener {
            val email = binding.inputForgotEmail.text.toString().trim()

            binding.txtError.visibility = android.view.View.GONE

            if (email.isEmpty()) {
                binding.txtError.text = "Email tidak boleh kosong!"
                binding.txtError.visibility = android.view.View.VISIBLE
                return@setOnClickListener
            }

            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                binding.txtError.text = "Format email tidak valid!"
                binding.txtError.visibility = android.view.View.VISIBLE
                return@setOnClickListener
            }

            binding.progressLoading.visibility = android.view.View.VISIBLE

            Handler(Looper.getMainLooper()).postDelayed({
                val intent = Intent(this, CheckEmail::class.java)
                intent.putExtra("email_user", email)
                startActivity(intent)
                finish()
            }, 2000)
        }
    }
}
